package com.generation.fooddelivery.api.dto;

import java.util.List;

import com.generation.fooddelivery.api.dto.DeliveryDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RestaurantDTO {
    
    int id;
    String name;
    String cityName;
    String address;
    int x,y;

    List<DeliveryDTO> deliveries;

}
