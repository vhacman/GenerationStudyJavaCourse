package com.generation.fooddelivery.api.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RiderDTO 
{
    private int id;
    private String nickname, phone, email, password;
    int x,y;

    private List<FeedbackDTO> feedbacks;
    private List<DeliveryDTO> deliveries;

}