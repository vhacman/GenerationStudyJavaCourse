package com.generation.fooddelivery.api;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.generation.fooddelivery.api.dto.RiderDTO;
import com.generation.fooddelivery.service.RiderService;
import com.generation.fooddelivery.service.ServiceException;

@RestController
@RequestMapping("/fooddelivery/api/riders")
public class RiderAPI 
{

    @Autowired
    RiderService riderService;

    
    @GetMapping("/{id}")
    public ResponseEntity<Object> findById(@PathVariable("id") int id) 
    {
        try 
        {
            RiderDTO loaded = riderService.findByID(id);
            return ResponseEntity.ok(loaded);
        }   
        catch(ServiceException e)
        {
            return ResponseEntity.notFound().build();
        }     
    }

    @GetMapping("/activebetween/{d1}/{d2}")
    public ResponseEntity<Object> findActive(@PathVariable("d1") LocalDateTime d1, @PathVariable("d2") LocalDateTime d2) 
    {
        return ResponseEntity.ok(riderService.findActiveBetween(d1, d2));
    }




}
