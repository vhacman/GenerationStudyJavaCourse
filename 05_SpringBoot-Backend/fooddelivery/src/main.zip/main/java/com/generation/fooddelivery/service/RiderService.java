package com.generation.fooddelivery.service;

import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.generation.fooddelivery.api.dto.RiderDTO;
import com.generation.fooddelivery.api.dto.RiderDTOMapper;
import com.generation.fooddelivery.model.entities.Rider;
import com.generation.fooddelivery.model.repository.RiderRepository;

/**
 * Un service è business logic.
 * Controlli, ragionamenti 
 * io NON SONO mappato. Il controller è mappato
 */
@Service 
public class RiderService 
{

    @Autowired
    RiderDTOMapper riderMapper;

    @Autowired
    RiderRepository riderRepo;


    public RiderDTO save(RiderDTO dto) throws ServiceException
    {
        Rider rider = riderMapper.toEntity(dto);
        if(riderRepo.exists(rider.getEmail()))
            throw new ServiceException("Rider already exists");

        rider = riderRepo.save(rider);

        return riderMapper.toDto(rider);
    }

    public RiderDTO findByID(int id) throws ServiceException
    {
        Optional<Rider> riderOpt = riderRepo.findById(id);
        if(riderOpt.isEmpty())
            throw new ServiceException("Rider not found");

        return riderMapper.toDto(riderOpt.get());
    }

    public List<RiderDTO> findActiveBetween(LocalDateTime d1, LocalDateTime d2) 
    {
        return riderMapper.toDto(riderRepo.findActiveBetween(d1, d2));
    }
    

}
