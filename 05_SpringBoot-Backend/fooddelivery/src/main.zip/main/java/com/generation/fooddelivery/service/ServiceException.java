package com.generation.fooddelivery.service;

public class ServiceException extends Exception
{
    int status;


    public ServiceException(String message)
    {
        super(message);
    }

    public ServiceException(String message, int status)
    {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }




}