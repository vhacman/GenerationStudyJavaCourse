package com.generation.fooddelivery.api.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeliveryDTO 
{
    private int id;
    private LocalDateTime deliveryTime;
    private String description;
    private String status;
    private int price;
    private int riderId;
    private int restaurantId;
    private String restaurantInfo;
    private String riderInfo;
    private String customerInfo;
    private String customerEmail;
    private String customerHash; // hash della password. NON VIENE TRADOTTA, viene gestita dal service

}
