package com.generation.fooddelivery.api;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.generation.fooddelivery.api.dto.DeliveryDTO;
import com.generation.fooddelivery.service.DeliveryService;
import com.generation.fooddelivery.service.ServiceException;

@RestController
@RequestMapping("fooddelivery/api/deliveries")
public class DeliveryAPI 
{
    @Autowired
    DeliveryService deliveryService;

    @GetMapping("/{id}")
    public ResponseEntity<Object> findById(@PathVariable("id") int id)
    {
        try
        {
            DeliveryDTO dto = deliveryService.findById(id);
            return ResponseEntity.ok(dto);
        }
        catch(ServiceException e)
        {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Object> newDelivery(@RequestBody DeliveryDTO dto)
    {
        try
        {
            DeliveryDTO saved = deliveryService.insert(dto);
            return ResponseEntity.status(203).body(saved);
        }
        catch(ServiceException e)
        {
            return ResponseEntity.status(e.getStatus()).body(e.getMessage());
        }

    }

}
