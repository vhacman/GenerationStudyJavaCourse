package com.generation.fooddelivery.api.dto;

import java.util.ArrayList;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.generation.fooddelivery.api.dto.RestaurantDTO;
import com.generation.fooddelivery.model.entities.Customer;
import com.generation.fooddelivery.model.entities.Restaurant;

@Mapper(componentModel = "spring", uses = {DeliveryDTOMapper.class })
public interface RestaurantDTOMapper 
{

    // la password non la convertiamo
    @Mapping(source="city.name", target="cityName")
    RestaurantDTO toDto(Restaurant entity);

    @Mapping(source="city.name", target="cityName")
    @Mapping(target="deliveries", ignore=true)
    RestaurantDTO toNakedDto(Restaurant entity);

    // Da DTO a Entità
    Restaurant toEntity(RestaurantDTO dto);


    default List<RestaurantDTO> toNakedDto(List<Restaurant> restaurants)
    {
        List<RestaurantDTO> dtos = new ArrayList<RestaurantDTO>();
        for(Restaurant restaurant:restaurants)
            dtos.add(toNakedDto(restaurant));
        return dtos;
    }


}