package com.generation.fooddelivery.api.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FeedbackDTO 
{
    private int id;
    private String text;
    private int score;
    private int riderId;
    
}
