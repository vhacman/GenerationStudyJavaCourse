package com.generation.fooddelivery.model.entities;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
@Getter 
@Setter
public class Delivery 
{

    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

    LocalDateTime deliveryTime;
    String description;
    int price;
    String status;

	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "rider_id") // Nome della colonna nel DB, FOREIGN KEY
    Rider rider;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "restaurant_id") // Nome della colonna nel DB, FOREIGN KEY
    Restaurant restaurant;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "customer_id") // Nome della colonna nel DB, FOREIGN KEY
    Customer customer;


}
