package com.generation.fooddelivery.api.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDTO 
{
    int id;
    String firstName, lastName, email, password, address;
    int x,y;
    int cityId;
    List<DeliveryDTO> deliveries;


}
