package com.generation.fooddelivery.api.dto;

import java.util.ArrayList;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.generation.fooddelivery.api.dto.RiderDTO;
import com.generation.fooddelivery.model.entities.Rider;

@Mapper(componentModel = "spring", uses = { FeedbackDTOMapper.class, DeliveryDTOMapper.class })
public interface RiderDTOMapper 
{

    // la password non la convertiamo
    @Mapping(target = "password", ignore = true)
    RiderDTO toDto(Rider rider);

    // Da DTO a Entità
    Rider toEntity(RiderDTO riderDto);

    // la password non la convertiamo
    @Mapping(target = "password", ignore = true)
    List<RiderDTO> toDto(List<Rider> riders);
    

}