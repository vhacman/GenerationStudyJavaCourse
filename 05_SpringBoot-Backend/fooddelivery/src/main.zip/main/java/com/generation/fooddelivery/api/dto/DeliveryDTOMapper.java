package com.generation.fooddelivery.api.dto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.generation.fooddelivery.model.entities.Delivery;

@Mapper(componentModel = "spring")
public interface DeliveryDTOMapper 
{
    @Mapping(source = "rider.id", target = "riderId")
    @Mapping(source="restaurant.id", target="restaurantId")
    @Mapping(source="restaurant.info", target="restaurantInfo")
    @Mapping(source="rider.info", target="riderInfo")
    @Mapping(source="customer.info", target="customerInfo")
    @Mapping(source="customer.email", target="customerEmail")
    DeliveryDTO toDto(Delivery delivery);


    Delivery toEntity(DeliveryDTO dto);
}
