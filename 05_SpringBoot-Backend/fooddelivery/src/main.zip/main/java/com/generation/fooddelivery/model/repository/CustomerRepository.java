package com.generation.fooddelivery.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.generation.fooddelivery.model.entities.Customer;

public interface CustomerRepository extends JpaRepository<Customer,Integer>
{

    @Query("select c from Customer c where email = :email and password = :hash")
    Customer login(@Param("email") String email, @Param("hash") String hash);
    
}
