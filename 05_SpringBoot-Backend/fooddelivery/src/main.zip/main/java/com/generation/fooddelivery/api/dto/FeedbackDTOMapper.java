package com.generation.fooddelivery.api.dto;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.generation.fooddelivery.api.dto.FeedbackDTO;
import com.generation.fooddelivery.model.entities.Feedback;

@Mapper(componentModel = "spring")
public interface FeedbackDTOMapper 
{
    
    // Spiegazione:
    // source = "rider.id" -> Vai nell'entità Feedback, prendi l'oggetto Rider e poi il suo Id
    // target = "riderId"  -> Scrivi quel valore nel campo riderId del FeedbackDTO
    @Mapping(source = "rider.id", target = "riderId")
    FeedbackDTO toDto(Feedback feedback);

    Feedback toEntity(FeedbackDTO dto);

}
