package com.generation.fooddelivery.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.generation.fooddelivery.model.entities.Rider;

import java.time.LocalDateTime;
import java.util.List;


public interface RiderRepository extends JpaRepository<Rider,Integer>
{
    List<Rider> findByEmail(String email);
    
    default boolean exists(String email)
    {
        return !findByEmail(email).isEmpty();
    }

    // questo è JPQL. E' il linguaggio di Query che legge da Hibernate, da JPA in geenere
    // mente SQL legge righe, hibernate legge entità
    // sto selezionando tutti i rider r dalla tabella r per distanza descrescente dai punti x,y che vengono passati come parametri
    // ma accetto solo quelli la cui distanza da x, y (((r.x - :x) * (r.x - :x) + (r.y - :y) * (r.y - :y))) è minore di squareDistance, la distanza massima
    /*
        select r from Rider -> (seleziono oggetti rider)
        where -> (filtro)
        ((r.x - :x) * (r.x - :x) + (r.y - :y) * (r.y - :y))<= :squareDistance -> la distanza da un centro (x,y) è minore o uguale di squareDistance
         and NOT EXISTS (SELECT d FROM Delivery d WHERE d.rider = r AND d.status = 'OPEN') -> e non ci sono delivery open per questo rider. Lo ottengo dalla tabella Delivery
         ORDER BY ((r.x - :x) * (r.x - :x) + (r.y - :y) * (r.y - :y)) DESC -> li ordino per distanza crescente da centro (x,y)
         LIMIT 1 -> prendo il primo della lista, quello per cui la distanza è minore
         E non preoccupatevi, è normale che sia orribile, ma non vi viene chiesto di farlo a mano... per ora    
    */
    @Query("SELECT r FROM Rider r WHERE ((r.x - :x) * (r.x - :x) + (r.y - :y) * (r.y - :y))<= :squareDistance and NOT EXISTS (SELECT d FROM Delivery d WHERE d.rider = r AND d.status = 'OPEN') ORDER BY ((r.x - :x) * (r.x - :x) + (r.y - :y) * (r.y - :y)) ASC LIMIT 1")
    Rider findNeareast(@Param("x") int x, @Param("y") int y, @Param("squareDistance") int squareDistance);


    // ricerca dei rider che hanno lavorato fra due date definite in input
    // sto partendo dal padre (rider) e sto facendo il join su deliveries (elementi figli)
    // dopo di che sto prendendo solo i padri (rider) che abbiano delivery (figli) in date comprese fra d1 e d2
    // non vi preoccupate di questa sintassi, usate le AI per tradurre il vostro desiderata in JPQL e poi verificatele
    @Query("SELECT r FROM Rider r JOIN r.deliveries d where d.deliveryTime between :d1 and :d2")
    List<Rider> findActiveBetween(@Param("d1") LocalDateTime d1, @Param("d2") LocalDateTime d2);



}
