package com.generation.fooddelivery.model.entities;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Rider 
{
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;


    // Yo so tu padre
	@OneToMany
	(
	    mappedBy = "rider", // Il nome del campo nell'entità figlio, uniscimeli in base alla chiave esterna
	    cascade = CascadeType.ALL, 
	    orphanRemoval = true // Se rimuovi una sanzione dalla lista, verrà cancellata dal DB
	)
	List<Feedback> feedbacks = new ArrayList<Feedback>();

    @OneToMany
	(
	    mappedBy = "rider", // Il nome del campo nell'entità figlio, uniscimeli in base alla chiave esterna
	    cascade = CascadeType.ALL, 
	    orphanRemoval = true // Se rimuovi una sanzione dalla lista, verrà cancellata dal DB
	)
	List<Delivery> deliveries = new ArrayList<Delivery>();


    private String nickname, email, password, phone;
    int x,y;

    // lo userò nel mapper
    public String getInfo()
    {
        return nickname+" "+email+" "+password+" "+phone;
    }

}
