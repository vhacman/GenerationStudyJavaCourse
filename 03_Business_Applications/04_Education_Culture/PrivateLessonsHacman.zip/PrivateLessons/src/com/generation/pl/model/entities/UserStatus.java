package com.generation.pl.model.entities;

public enum UserStatus
{
	ACTIVE,
	BANNED,
	PENDING;
}
